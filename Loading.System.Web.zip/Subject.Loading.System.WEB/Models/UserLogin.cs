﻿namespace Subject.Loading.System.WEB.Models
{
    public class UserLogin
    {
        public string UserName { get; set; }

        public string Password { get; set; }
    }
}
