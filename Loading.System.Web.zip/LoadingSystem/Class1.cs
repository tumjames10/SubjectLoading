﻿namespace LoadingSystem
{
    public class Class1
    {

    }
}